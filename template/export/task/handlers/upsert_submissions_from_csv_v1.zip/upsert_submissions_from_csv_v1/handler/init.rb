# Require the dependencies file to load the vendor libraries
require File.expand_path(File.join(File.dirname(__FILE__), "dependencies"))

class UpsertSubmissionsFromCsvV1
  # ==== Parameters
  # * +input+ - The String of Xml that was built by evaluating the node.xml handler template.
  def initialize(input)
    # Set the input document attribute
    @input_document = REXML::Document.new(input)

    # Retrieve all of the handler info values and store them in a hash variable named @info_values.
    @info_values = {}
    REXML::XPath.each(@input_document, "/handler/infos/info") do |item|
      @info_values[item.attributes["name"]] = item.text.to_s.strip
    end

    # Retrieve all of the handler parameters and store them in a hash variable named @parameters.
    @parameters = {}
    REXML::XPath.each(@input_document, "/handler/parameters/parameter") do |item|
      if item.attributes["name"] == "unique_id_column_name"
        @parameters[item.attributes["name"]] = item.text.to_s
      else
        @parameters[item.attributes["name"]] = item.text.to_s.strip
      end
    end

    @debug_logging_enabled = ["yes","true"].include?(@info_values['enable_debug_logging'].downcase)
    @error_handling = @parameters["error_handling"]

    @api_location = @info_values["api_location"]
    @api_location.chomp!("/")
    @api_username = @info_values["api_username"]
    @api_password = @info_values["api_password"]

    @accept = :json
    @content_type = :json

    # It may make sense to parameterize this value.
    # For some processes an error is generated with this set to the default (10240), or lesser values.
    REXML::Security.entity_expansion_text_limit=(163840)

  end

  def execute
    # Initialize return data
    error_message = nil
    data_submissions_unique_ids = []
    additions = []
    missing = []
    changes = []

    response_code = nil

    begin
      csv_query = evaluate_csv_query()

      # Retrieve Data Submissions
      data_submissions = {}
      unique_ids_failed_submissions = []
      next_page_token = ""
      retrieve_loop_iteration = 0
      csv_rows_matching_query = 0

      puts "Retrieve Previous Data - Begin" if @debug_logging_enabled
      loop do
        retrieve_loop_iteration += 1
        puts "Retrieval Query Number: #{retrieve_loop_iteration}" if @debug_logging_enabled
        # Get first set previous submissons
        data_submissions_response = get_previous_records(next_page_token)
        # Parse JSON response
        data_submissions_response_body = JSON.parse(data_submissions_response.body)
        # Update next_page_token
        next_page_token = data_submissions_response_body['nextPageToken']
        # Extract results into the previous submissions array
        data_submissions_raw = data_submissions_response_body['submissions']
        data_submissions_raw.each{|submission|
          data_submissions[submission['values'][@parameters['unique_id_field_name']]] = submission
        }
        # Break the loop if the next page token is empty (meaning there are no more records)
        break if next_page_token.to_s.empty?
      end
      data_submissions_unique_ids = data_submissions.keys
      puts "Retrieve Previous Data - End" if @debug_logging_enabled

      puts "Retrieving File" if @debug_logging_enabled
      puts "FILE URI: #{@parameters['attachment_retrieve_url']}" if @debug_logging_enabled
      ## Retrieve File content
      uri = URI.parse( @parameters['attachment_retrieve_url'] )
      request = Net::HTTP::Get.new(uri)
      request.basic_auth(@api_username, @api_password)

      req_options = {
        use_ssl: uri.scheme == "https",
        #verify_mode: OpenSSL::SSL::VERIFY_NONE
      }

      file_response = Net::HTTP.start(uri.hostname, uri.port, req_options) do |http|
        http.request(request)
      end

      puts "File Retrieved" if @debug_logging_enabled
      puts "File Content:\n#{file_response.body}" if @debug_logging_enabled

      # Define variable for all keys in csv file
      csv_unique_ids = []
      csv_adds = []
      comparison_mapping = JSON.parse(@parameters['fields_to_compare_mapping'])

      ## Parse into CSV:
      # data = CSV.parse(response.body)
      # Use Headers:
      #CSV.parse((file_response.body), headers: true) {|row|
      # csv_table = CSV.parse((file_response.body), headers: true)
      # Force UTF-8 encoding, and remove the BOM character if it exists.
      csv_table = CSV.parse(((file_response.body.force_encoding("utf-8")).sub("\xEF\xBB\xBF".force_encoding("UTF-8"), '')), headers: true)

      csv_table.each{|row|
        # Evaluate Row based on criteria
        row_meets_criteria = true
        if !csv_query.empty?
          csv_query.each{|qual|
            #raise "\"#{row[qual['Column']]}\"#{qual['Operator']}\"#{qual['Value'].to_s}\""
            if qual['Operator'].downcase == "empty"
              if !(eval("#{row[qual['Column']].to_s.empty?}"))
                row_meets_criteria = false
                break
              end
            elsif qual['Operator'].downcase == "!empty"
              if !(eval("#{!row[qual['Column']].to_s.empty?}"))
                row_meets_criteria = false
                break
              end
            elsif !(eval("\"#{row[qual['Column']]}\"#{qual['Operator']}\"#{qual['Value'].to_s}\""))
              row_meets_criteria = false
              break
            else
              row_meets_criteria = true
            end
          }
        end

        if row_meets_criteria
          csv_rows_matching_query += 1

          # Add row unique identifier to CSV Unique IDs array
          csv_unique_ids.push(row[@parameters['unique_id_column_name']])

          ## Find Adds
          if !data_submissions_unique_ids.include?(row[@parameters['unique_id_column_name']])
            # Define the values object to be submitted with the API call
            # row.to_hash --> This ignores fields order and clobbers duplicately named columns

            puts "Row data: #{row.to_hash.to_json}" if @debug_logging_enabled
            additions.push(row.to_hash)
            # write record
            #  create values defaults
            values = JSON.parse(@parameters['additional_data_elements'] || "{}")
            comparison_mapping.each{|form_field,header_column|
              values[form_field] = row[header_column]
            }
            #  call process to create record
            #  process needs to attempt to write record as completed = true.  If fails, capture output and write again as draft, with errors in Data Errors record
            id = add_record(values)
          else  # evaluate for change
            different = false
            # Retrieve Submission
            submission_data = data_submissions[row[@parameters['unique_id_column_name']]]
            # Compare data
            comparison_mapping.each{|form_field,header_column|
              if submission_data['values'][form_field] != row[header_column]
                different=true
                break
              end
            }

            if different
              # add submission id to the row
              row_hash = row.to_hash{}
              row_hash['kinetic'] = {'submission_id' => submission_data['id']}

              # row.to_hash --> This ignores fields order and clobbers duplicately named columns
              #changes.push(row.to_hash{})
              changes.push(row_hash)
            end
          end
        end
      }

      # Find missing, by taking the different of the unique arrays
      missing = data_submissions_unique_ids - csv_unique_ids
      # Convert missing from a simple array of items to an array of hashes, which include the submission_id of the missing entry
      missing.each_index{|idx|
        missing[idx] = {missing[idx] => {"kinetic" => {"submission_id" => data_submissions[missing[idx]]['id'] }}}
      }

      output = {
        "CSV File Rows" => (csv_table || []).size,
        "Data Rows" => data_submissions_unique_ids.size,
        "CSV Rows Matching Query" => csv_rows_matching_query,
      }.to_json

    rescue => e
      #error_message = e.inspect
      #raise if @error_handling == "Raise Error"
      raise
    end

    # Return (and escape) the results that were defined in the node.xml
    <<-RESULTS
    <results>
      <result name="CSV File Rows">#{escape(JSON.parse(output)['CSV File Rows'])}</result>
      <result name="CSV Rows Matching Query">#{escape(JSON.parse(output)['CSV Rows Matching Query'])}</result>
      <result name="Retrieved Data Rows">#{escape(JSON.parse(output)['Data Rows'])}</result>
      <result name="Additions Count">#{escape(additions.size)}</result>
      <result name="Additions JSON">#{escape(additions.to_json)}</result>
      <result name="Missing Count">#{escape(missing.size)}</result>
      <result name="Missing JSON">#{escape(missing.to_json)}</result>
      <result name="Changes Count">#{escape(changes.size)}</result>
      <result name="Changes JSON">#{escape(changes.to_json)}</result>
      <result name="Handler Error Message">#{escape(error_message)}</result>
    </results>
    RESULTS
  end

  ##############################################################################
  # General handler utility functions
  ##############################################################################

  # This is a template method that is used to escape results values (returned in
  # execute) that would cause the XML to be invalid.  This method is not
  # necessary if values do not contain character that have special meaning in
  # XML (&, ", <, and >), however it is a good practice to use it for all return
  # variable results in case the value could include one of those characters in
  # the future.  This method can be copied and reused between handlers.
  def escape(string)
    # Globally replace characters based on the ESCAPE_CHARACTERS constant
    string.to_s.gsub(/[&"><]/) { |special| ESCAPE_CHARACTERS[special] } if string
  end

  def evaluate_csv_query()
    begin
      @parameters['csv_query'] = "[]" if @parameters['csv_query'].strip == ''
      csv_query = JSON.parse(@parameters['csv_query'])
      is_valid = true
      messages = []

      if csv_query.empty?
        return csv_query
      else
        csv_query.each_index{|qual_index|
          qual = csv_query[qual_index]
          keys = qual.keys
          keys.map!{|key|
            key.downcase
          }

          if !keys.include?("column") || !keys.include?("operator")
            is_valid = false
            messages.push("Qualification #{qual_index + 1} is missing the Column or Operator")
            next
          end

          if !["==", "<", ">", "!=", "empty", "!empty"].include?(qual['Operator'].downcase)
            is_valid = false
            messages.push(%|Qualification #{qual_index + 1} is has an invalid Operator.  Only "==", "<", ">", "!=", "Empty", "!Empty" are allowed|)
            next
          end

          if !["empty","!empty"].include?(qual['Operator'].to_s.downcase) && !keys.include?("value")
            is_valid = false
            messages.push("Qualification #{qual_index + 1} is missing the Value")
            next
          end
        }
      end

      if !is_valid
        raise "CSV Query is invalid: \n #{messages.join("\n")}"
      else
        return csv_query
      end
    rescue JSON::ParserError => e
      raise "JSON Parse error of the CSV Query.\n\n#{e}"
    rescue Exception => e
      raise
    end

  end

  # This method is to return a set of records from the
  def get_previous_records(next_page_token)
    #query = %|values[#{@parameters['line_item_file_submission_id_field_name']}] = "#{@parameters['file_attachment_submission_id']}"|
    query = @parameters['data_query']
    order_by = @parameters['data_order_by']
    includes = "values"
    api_route = "#{@api_location}/kapps/#{@parameters['kapp_slug_data']}/forms/#{@parameters['form_slug_data']}/submissions?limit=1000&q=#{ERB::Util.url_encode(query)}&orderBy=#{ERB::Util.url_encode(order_by)}&include=#{ERB::Util.url_encode(includes)}"
    api_route = "#{api_route}&pageToken=#{next_page_token}" if !next_page_token.to_s.empty?


    puts "API ROUTE FOR DATA SUBMISSIONS: #{@method.to_s.upcase} #{api_route}" if @debug_logging_enabled

    begin
      response = RestClient::Request.execute \
        method: :get, \
        url: api_route, \
        user: @api_username, \
        password: @api_password, \
        headers: {:content_type => @content_type, :accept => @accept}
      response_code = response.code

    rescue RestClient::Exception => e
      # Attempt to parse the JSON error message.
  ##    begin
  ##      error = nil
  ##      response_code = e.response.code
  ##      error = JSON.parse(e.response)
  ##      error_message = error["error"]
  ##    rescue Exception
  ##      puts "There was an error parsing the JSON error response" if @debug_logging_enabled
  ##      error_message = e.inspect
  ##    end
      # Raise the error if instructed to, otherwise will fall through to
      # return an error message.
  ##    raise if @error_handling == "Raise Error"
      raise
    end

    return response.body

  end

  def add_record(values)
    puts "Values #{values.inspect}" if @debug_logging_enabled
    includes = "values"
    api_route = "#{@api_location}/kapps/#{@parameters['kapp_slug_data']}/forms/#{@parameters['form_slug_data']}/submissions?include=#{ERB::Util.url_encode(includes)}&completed=true"
    puts "API ROUTE FOR DATA ADD: #{@method.to_s.upcase} #{api_route}" if @debug_logging_enabled

    begin
      response = RestClient::Request.execute \
        method: :post, \
        url: api_route, \
        user: @api_username, \
        password: @api_password, \
        headers: {:content_type => @content_type, :accept => @accept}, \
        payload: {"values" => values}.to_json
      response_code = response.code

      return JSON.parse(response.body)['submission']['id']
    rescue RestClient::BadRequest => e
      response_body = JSON.parse(e.response.body)
      puts "Reponse Body - Bad Request Block Rescue: #{response_body}"
      values['Data Errors'] = response_body['error']
      api_route = "#{@api_location}/kapps/#{@parameters['kapp_slug_data']}/forms/#{@parameters['form_slug_data']}/submissions?include=#{ERB::Util.url_encode(includes)}&completed=false"
      puts "API ROUTE FOR DATA ADD WITH FIELD VALIDATION ISSUES: #{@method.to_s.upcase} #{api_route}" if @debug_logging_enabled
      begin
        response = RestClient::Request.execute \
          method: :post, \
          url: api_route, \
          user: @api_username, \
          password: @api_password, \
          headers: {:content_type => @content_type, :accept => @accept}, \
          payload: {"values" => values}.to_json
        response_code = response.code

        #return JSON.parse(response.body)['body']['submission']['id']
        return JSON.parse(response.body)['submission']['id']
      rescue RestClient::Exception => e
        # Need to determine what we should do here
        raise
      end
    rescue RestClient::Exception => e
      # Need to determine what we should do here
      raise
    end
  end

  # This is a ruby constant that is used by the escape method
  ESCAPE_CHARACTERS = {'&'=>'&amp;', '>'=>'&gt;', '<'=>'&lt;', '"' => '&quot;'}

end
