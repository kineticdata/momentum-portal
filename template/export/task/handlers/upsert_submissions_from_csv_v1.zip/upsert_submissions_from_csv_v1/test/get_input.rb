{
  'info' => {
    'api_username' => "",
    'api_password' => "",
    'api_location' => "",
    'enable_debug_logging' => 'true'
  },
  'parameters' => {
    'error_handling' => 'Error Message',
    'unique_id_column_name' => 'Employee Number',
    'attachment_retrieve_url' => 'https://momentum-dev.kinopsdev.io/submissions/cf9a9de3-68d3-11f0-904e-898b17c664e1/files/Area%201%20File%20Attachment/0/data-collection-form-1-002.csv',
    'attachment_reference' => '100',
    'kapp_slug_data' => 'service-portal',
    'form_slug_data' => 'data-collection-form-1',
    'data_query' => 'values[Customer Identifier]="KD Construction, Inc."',
    'data_order_by' => 'createdAt',
    'unique_id_field_name' => 'Employee Number',
    'csv_query' => '',
    'fields_to_compare_mapping' => '{"Employee Number": "Employee Number","Base Salary":"Base Salary","Bonus Percent":"Bonus Percent","Merit Increase Percent":"Merit Increase Percent","Bonus Eligible":"Bonus Eligible"}',
    'additional_data_elements' => '{"Year": "2025","Customer Identifier": "KD Construction, Inc.","File Attachment Reference": "100"}'
  }
}
